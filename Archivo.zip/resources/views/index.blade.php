<!DOCTYPE html>
<html lang="en">
<head>
  @include('components.assets')
</head>

<body class="has-navbar-vertical-aside navbar-vertical-aside-show-xl   footer-offset">
    @include('components.topbar')
    @include('components.navbar')

    <main id="content" role="main" class="main">


        @include('components.footer')
    </main>
    @include('components.assetstop')
</body>
</html>